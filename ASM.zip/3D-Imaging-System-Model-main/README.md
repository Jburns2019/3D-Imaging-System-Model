# 3D-Imaging-System-Model
An approximately to scale model of a theorized 3D Imaging System. The intent of the Imaging System was to make viewing 3D images more intuitive. The current mode is often using 2D and then extrapolating 3D. There wasn't a commercially readily available way of viewing something in pixelated 3D at the time of conceptualization.
